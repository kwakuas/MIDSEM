<?php include "db_connect.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Students</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f3; padding: 20px; }
        h2 { text-align: center; }
        table { width: 80%; margin: auto; border-collapse: collapse; background: white; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background: #4CAF50; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        a { display: block; text-align: center; margin-top: 20px; }
    </style>
</head>
<body>
    <h2>Registered Students</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Index Number</th>
            <th>Gender</th>
        </tr>
        <?php
        $sql = "SELECT id, name, index_number, gender FROM student";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row['id']."</td>
                        <td>".$row['name']."</td>
                        <td>".$row['index_number']."</td>
                        <td>".$row['gender']."</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No students registered yet.</td></tr>";
        }
        ?>
    </table>
    <a href="register.php">← Back to Registration</a>
</body>
</html>